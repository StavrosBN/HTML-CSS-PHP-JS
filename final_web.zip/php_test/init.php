<?php
session_start(); // Start the session
include 'db_connect.php';
?>
